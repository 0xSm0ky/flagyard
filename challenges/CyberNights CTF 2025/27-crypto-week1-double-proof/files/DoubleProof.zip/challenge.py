from random import randint
from Crypto.Util.number import isPrime, bytes_to_long, getPrime

FLAG = open("flag.txt", "rb").read()
s = bytes_to_long(FLAG)
q = getPrime(512)
p = 2*q + 1
g = 2
h = 3

while not isPrime(p):
    q = getPrime(512)
    p = 2*q + 1

u = pow(g, s, q)
v = pow(h, s, q)
r = randint(0, q)

def verify(a, b, z, e):
    return pow(g,z,p) == a*pow(u,e,p) % p and pow(h,z,p) == b*pow(v,e,p) % p

def main(i):
    if i == 'p':
        a = pow(g, r, p)
        b = pow(h, r, p)
        e = int(input("e: "))
        z = (r + e*s) % q
        print(f"{z=}")
    elif i == 'v':
        try:
            a, b, z, e = map(int, input("abze=").split(":"))
            if verify(a, b, z, e):
                print("Correct")
            else:
                print("Wrong Proof")
        except:
            exit(0)

if __name__ == "__main__":
    banner = '''
            [WELCOME TO DOUBLE PROOF SERVER]

    [V]erify
    [P]rove
'''
    print(banner)
    print(f"{p=}\n{q=}\n")
    while True:
        i = input("> ").lower()
        main(i)




