from Crypto.Util.number import  getPrime, isPrime
from secrets import randbelow
import hashlib

def main():

    p = getPrime(128)
    sList = [randbelow(p) for i in range(90)]
    flag = open("flag.txt", "rb").read()
    secret = randbelow(2**90)

    x = 1
    for i in range(90):
        if (secret >> i) & 1:
            x *= sList[i] % p
        x %= p

    h = hashlib.sha256(str(secret).encode('utf-8')).digest()
    mask = int.from_bytes(h, "big")^int.from_bytes(flag, "big")

    print(f"Imagine you're working on a Field module {p}")
    print(f"{sList=}")
    print(f"{x=}")
    print(f"{mask=}")

if __name__ == "__main__":
    banner = '''
     __  __  ____   __  _   _   _    
    |  \/  \|  \ `v' / | | | | | |   
    | -< /\ | -<`. .'  | |_| |_| |_  
    |__/_||_|__/ !_!   |___|___|___| 

    This is not LLL challenge!

'''
    print(banner)
    main()